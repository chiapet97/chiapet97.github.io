a_count = 0
b_count = 0
c_count = 0
d_count = 0

print ("Hey, its Zee the dinosaur!")
begin = input("Wanna play the game? Enter yes to play:")
if begin == "yes":
  
   q1_answer = input("\nWell since I am a DIYnoSNORE, do you snore?\n\n(a) Sorry DIYnoSNORE, but I do regularly.\n(b) I guess I would have to say often.\n(c) To be honest, I snore sometimes.\n(d) HAHAHA, I am with you DIYnoSNORE, I rarely/never snore.\n")
   if q1_answer.lower() == 'a':
       a_count += 1
   elif q1_answer.lower() == 'b':
       b_count += 1
   elif q1_answer.lower() == 'c':
       c_count += 1
   elif q1_answer.lower() == 'd':
       d_count += 1

   else:
      
    print("Please pick a,b,c, or d.")
    q1_answer = input("\nWell since I am a DIYnoSNORE, do you snore?\n\n(a) Sorry DIYnoSNORE, but I do regularly.\n(b) I guess I would have to say often.\n(c) To be honest, I snore sometimes.\n(d) HAHAHA, I am with you DIYnoSNORE, I rarely/never snore.\n")
    if q1_answer.lower() == 'a':
       a_count += 1
    elif q1_answer.lower() == 'b':
       b_count += 1
    elif q1_answer.lower() == 'c':
       c_count += 1
    elif q1_answer.lower() == 'd':
       d_count += 1
    
    
   q2_answer = input("\nZee has never fallen asleep while driving. Have you?\n\n(a) Well DIYnoSNORE, I may have done it once or twice.\n(b) I have almost, but never actually done it.\n(c) I felt drowsy while driving, but never even almost did.\n(d) What's that? Do you even know me DIYnoSNORE?\n")
   if q2_answer.lower() == 'a':
       a_count += 1
   elif q2_answer.lower() == 'b':
       b_count += 1
   elif q2_answer.lower() == 'c':
       c_count += 1
   elif q2_answer.lower() == 'd':
       d_count += 1
   else:
       print("Please pick a,b,c, or d.")
       q2_answer = input("\nZee has never fallen asleep while driving. Have you?\n\n(a) Well DIYnoSNORE, I may have done it once or twice.\n(b) I have almost, but never actually done it.\n(c) I felt drowsy while driving, but never even almost did.\n(d) What's that? Do you even know me DIYnoSNORE?\n")
   if q2_answer.lower() == 'a':
       a_count += 1
   elif q2_answer.lower() == 'b':
       b_count += 1
   elif q2_answer.lower() == 'c':
       c_count += 1
   elif q2_answer.lower() == 'd':
       d_count += 1

   q3_answer = input("\nZee is full of energy after a full night of sleep. Do you feel energized after sleeping?\n\n(a) Sorry Zee, but I feel like a zombie when I wake up in the morning.\n(b) Most days I still feel tired, but it could just be the thought of going to work/school.\n(c) I'm a pretty happy soul, but sometimes I do have one of those days.\n(d) My life motto is - the energized bird gets the worm!\n")
   if q3_answer.lower() == 'a':
          a_count += 1
   elif q3_answer.lower() == 'b':
          b_count += 1
   elif q3_answer.lower() == 'c':
          c_count += 1
   elif q3_answer.lower() == 'd':
          d_count += 1
   else:
          print("Please pick a,b,c, or d.")
          q3_answer = input("\nZee is full of energy after a full night of sleep. Do you feel energized after sleeping?\n\n(a) Sorry Zee, but I feel like a zombie when I wake up in the morning.\n(b) Most days I still feel tired, but it could just be the thought of going to work/school.\n(c) I'm a pretty happy soul, but sometimes I do have one of those days.\n(d) My life motto is - the energized bird gets the worm!\n")
   if q3_answer.lower() == 'a':
          a_count += 1
   elif q3_answer.lower() == 'b':
          b_count += 1
   elif q3_answer.lower() == 'c':
          c_count += 1
   elif q3_answer.lower() == 'd':
          d_count += 1
    

   q4_answer = input( "\nZee's slogan is: breathe in through your nose, and out through your mouth. What's yours?\n\n(a) Always breathe out the mouth.\n(b) Breathing out my mouth is aight.\n(c) Breathing out my nose is better, but breathing out my mouth is chill.\n(d) Zee relates to me.\n")
   if q4_answer.lower() == 'a':
          a_count += 1
   elif q4_answer.lower() == 'b':
          b_count += 1
   elif q4_answer.lower() == 'c':
          c_count += 1
   elif q4_answer.lower() == 'd':
          d_count += 1
   else:
          print("Please pick a,b,c, or d.")
          q4_answer = input( "\nZee's slogan is: breathe in through your nose, and out through your mouth. What's yours?\n\n(a) Always breathe out the mouth.\n(b) Breathing out my mouth is aight.\n(c) Breathing out my nose is better, but breathing out my mouth is chill.\n(d) Zee relates to me.\n")
   if q4_answer.lower() == 'a':
          a_count += 1
   elif q4_answer.lower() == 'b':
          b_count += 1
   elif q4_answer.lower() == 'c':
          c_count += 1
   elif q4_answer.lower() == 'd':
          d_count += 1
    

   q5_answer = input("\nDIYnoSNORE sleeps as snug as a bug in a rug. What about you?\n\n(a) Usually wake up a couple of times during the night.\n(b) Don't usually wake up, but it could happen.\n(c) Maybe once every 2 months more or less.\n(d) The only thing that wakes me up is my alarm.\n")
   if q5_answer.lower() == 'a':
          a_count += 1
   elif q5_answer.lower() == 'b':
          b_count += 1
   elif q5_answer.lower() == 'c':
          c_count += 1
   elif q5_answer.lower() == 'd':
          d_count += 1
   else:
          print("Please pick a,b,c, or d.")
          q5_answer = input("\nDIYnoSNORE sleeps as snug as a bug in a rug. What about you?\n\n(a) Usually wake up a couple of times during the night.\n(b) Don't usually wake up, but it could happen.\n(c) Maybe once every 2 months more or less.\n(d) The only thing that wakes me up is my alarm.\n")
   if q5_answer.lower() == 'a':
          a_count += 1
   elif q5_answer.lower() == 'b':
          b_count += 1
   elif q5_answer.lower() == 'c':
          c_count += 1
   elif q5_answer.lower() == 'd':
          d_count += 1
    
   q6_answer = input( "\nZee's head only hurts when his wife yells at him. What about you?\n\n(a) That and also almost every morning.\n(b) Not always from a restless night of sleep.\n(c) From time to time, but mostly because of work.\n(d) Never unless I have had a really stressful day.\n")
   if q6_answer.lower() == 'a':
          a_count += 1
   elif q6_answer.lower() == 'b':
          b_count += 1
   elif q6_answer.lower() == 'c':
          c_count += 1
   elif q6_answer.lower() == 'd':
          d_count += 1
   else:
          print("Please pick a,b,c, or d.")
          q6_answer = input( "\nZee's head only hurts when his wife yells at him. What about you?\n\n(a) That and also almost every morning.\n(b) Not always from a restless night of sleep.\n(c) From time to time, but mostly because of work.\n(d) Never unless I have had a really stressful day.\n")
   if q6_answer.lower() == 'a':
          a_count += 1
   elif q6_answer.lower() == 'b':
          b_count += 1
   elif q6_answer.lower() == 'c':
          c_count += 1
   elif q6_answer.lower() == 'd':
          d_count += 1
    
    
   if a_count > b_count and a_count > c_count and a_count > d_count:
       print("Your result:\n")
       print("I, Zee highly recommend that you visit your doctor about the disorder sleep apnea.\n")

   elif b_count > c_count and b_count > d_count and b_count > a_count:
       print("Your result:\n")
       print("There is a moderate chance that you have the sleep disorder sleep apnea. DIYnoSNORE says a trip to the doctor is recommened.\n")

   elif c_count > d_count and c_count > a_count and c_count > b_count:
       print("Your result:\n")
       print("There is a very low chance that you have the disorder sleep apnea.\n")

   elif d_count > a_count and d_count > b_count and d_count > c_count:
       print("Your result:\n")
       print("It is very unlikely that you have the disorder sleep apena based your responses. However, you should still get a professional opinion.\n")
  
   else:
       print("Your result:\n")
       print("Based on your responses, it has been concluded that the best course of action is to go see a doctor.")

       